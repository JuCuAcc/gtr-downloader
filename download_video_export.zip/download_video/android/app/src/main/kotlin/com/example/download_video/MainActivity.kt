package com.example.download_video

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
